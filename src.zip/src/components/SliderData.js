import doctor1 from '../assets/dr1.png';
import doctor2 from '../assets/dr2.png';
import doctor3 from '../assets/dr3.png'; 
import doctor4 from '../assets/dr4.png'; 



export let SliderData = [
{
   img: doctor1,
   title:"Emad Abdallah",
   Text: "Nose, ear and throat surgery",
   FB  :"Clear feedback on how to improve their performance Share your feedback on our help forum."

},
{
    img: doctor2,
    title:"Hany Khalil",
    Text: "Dermatology and Andrology",
    FB :"I'd love your feedback on my decision on repurposing my crochet pillows."

}]

export let SliderData2 =[

    {
        img: doctor3,
        title:" Rania Samy",
        Text: "Ggynecology & infertility",
        FB  :"In addition, no feedback on the comments of the parties was provided."
    
    },
    {
        img: doctor4,
        title:"Shaimaa ElMaaty",
        Text: "Dermatology and laser Consultant",
        FB: "And with each version, kids get instant feedback about what works and what doesn't work."
    
    }
  
]




